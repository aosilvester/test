// this file needs contents in order to be treated as a module by typescript with the '--isolatedModules' flag, you may delete these unused contents
export const unused = "deleteMe"