import React, { Component } from "react";
import "./details.css";

class DetailsComponent extends Component {
  render() {
    const notes = this.props.notes[0].notes;

    const currentNoteIndex = this.props.currentNoteIndex;
    return (
      <section className="NoteDetails">
        {/* TODO some rendering bugs in here when list is empty */}

        {this.props.notes.length && (
          <h3 className="NoteDetails-title">
            {notes[this.props.currentNoteIndex].subject}
          </h3>
        )}
        {notes.length && (
          <p className="NoteDetails-subject">{notes[currentNoteIndex].body}</p>
        )}
        <button
          onClick={(e) => {
            this.props.markAsRead(currentNoteIndex, notes);
          }}
        >
          Mark as read
        </button>
      </section>
    );
  }
}

export default DetailsComponent;
