import React, { Component } from "react";
import logo from "./logo.svg";

class HeaderDivComponent extends Component {
  countUnread() {
    var unread = 0;
    var notes = this.props.notes[0].notes;
    notes.forEach((note) => {
      if (note.read === false) {
        unread++;
      }
    });
    return unread;
  }

  render() {
    return (
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1 className="App-title">Notes Viewer Test App</h1>
        <div>
          Unread:
          <span className="App-title-unread-count">{this.countUnread()}</span>
        </div>
      </header>
    );
  }
}

export default HeaderDivComponent;
