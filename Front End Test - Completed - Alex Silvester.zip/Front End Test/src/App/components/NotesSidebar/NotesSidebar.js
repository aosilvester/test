import React, { Component } from "react";
import checkMark from "./check-mark.svg";
import classNames from "classnames";
import "./notesSideBar.css";

class NotesSidebarDivComponent extends Component {
  state = {
    selectedNote: [],
  };

  getNotesRows() {
    const notes = this.props.notes.notes[0].notes;
    let notesHTML = notes.map((note) => {
      const keyID = notes.indexOf(note);
      return (
        <div
          key={keyID}
          className={
            this.state.selectedNote === keyID
              ? classNames("NotesSidebaritem", "selected")
              : classNames("NotesSidebaritem")
          }
          onClick={() => {
            this.selectNoteClass(keyID);
            this.props.selectNote(keyID);
          }}
        >
          <h4 className={classNames("NotesSidebarItem-title")}>
            {note.subject}
          </h4>
          {note.read && <img alt="Check Mark" src={checkMark} />}
        </div>
      );
    });
    return notesHTML;
  }

  selectNoteClass(noteID) {
    this.setState({ selectedNote: noteID });
  }

  render() {
    return (
      <section className="NotesSideBar">
        <h2 className="NotesSidebar-title">Available Notes:</h2>
        <div className="NotesSidebar-list">{this.getNotesRows()}</div>
      </section>
    );
  }
}

export default NotesSidebarDivComponent;
