import './App.scss';
import * as React from 'react';

import HeaderDivComponent from './components/Header/header';
import NotesSidebarDivComponent from './components/NotesSidebar/NotesSidebar'
import DetailsComponent from './components/Details/Details'
import notes from '../db.json'

class App extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      notes: [notes],
      currentNoteIndex: 0
    };
  }

  markAsRead = (i:number, notes:any) => {
    console.log(i)
    var newState = notes.map((note:any) => {
      if(note === this.state.notes[0].notes[i]){
        note.read = true
      }
      return note
    });
    this.setState([{'notes': newState}])
  }

  selectNote = (id:number) => {
      this.setState({currentNoteIndex: id})
    }
   
  render() {
    return (
      <div className='App'>
        <HeaderDivComponent notes={this.state.notes}/>
        <NotesSidebarDivComponent notes={this.state} selectNote={this.selectNote}/>
        <DetailsComponent notes={this.state.notes} currentNoteIndex={this.state.currentNoteIndex} markAsRead={this.markAsRead}/>
      </div>
    );
  }
}

export default App;
